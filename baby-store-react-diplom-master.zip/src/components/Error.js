import React from "react";
const Error = () => {
  return (
    <div className="section section-center text-center">
      <h2>была допущена ошибка...</h2>
    </div>
  );
};

export default Error;
